#include "FWCore/MessageLogger/interface/Colors.h"

const char * raveimpl::colors::black() { return "[0;30m"; }
const char * raveimpl::colors::red() { return "[0;31m"; }
const char * raveimpl::colors::green() { return "[0;32m"; }
const char * raveimpl::colors::yellow() { return "[0;33m"; }
const char * raveimpl::colors::blue() { return "[0;34m"; }
const char * raveimpl::colors::magenta() { return "[0;35m"; }
const char * raveimpl::colors::cyan() { return "[0;36m"; }
const char * raveimpl::colors::reset() { return "[;0m"; }
