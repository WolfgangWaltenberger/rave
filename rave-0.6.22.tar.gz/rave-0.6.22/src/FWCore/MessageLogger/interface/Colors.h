#ifndef MessageLogger_Colors_h
#define MessageLogger_Colors_h

namespace raveimpl {
  namespace colors {
    const char * black();
    const char * red();
    const char * green();
    const char * yellow();
    const char * blue();
    const char * magenta();
    const char * cyan();
    const char * reset();
  }
}

#endif
