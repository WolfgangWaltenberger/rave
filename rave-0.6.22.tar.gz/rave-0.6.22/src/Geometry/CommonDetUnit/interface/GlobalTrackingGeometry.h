#ifndef CommonDetUnit_GlobalTrackingGeometry_H
#define CommonDetUnit_GlobalTrackingGeometry_H

class GlobalTrackingGeometry {
};

#endif
