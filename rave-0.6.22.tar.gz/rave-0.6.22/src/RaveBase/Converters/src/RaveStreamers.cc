#include "RaveBase/Converters/interface/RaveStreamers.h"
#include <iomanip>
#include <iostream>

using namespace std;

namespace
{
  bool isDiagonal ( const rave::Covariance3D & cov )
  {
    static const float min = 1.e-11;
    if ( fabs ( cov.dxy() ) > min ) return false;
    if ( fabs ( cov.dxz() ) > min ) return false;
    if ( fabs ( cov.dyz() ) > min ) return false;
    return true;
  }
}

ostream& operator<< ( ostream& os, const rave::Point3D & p )
{
  os << "(" << setprecision(4) << fixed << p.x() << ", " << p.y() << ", " << p.z() << ")";
  return os;
}

#ifdef WITH_KINEMATICS
ostream& operator<< ( ostream& os, const rave::Vector4D & p )
{
  os << "(" << setprecision(4) << fixed << p.x() << ", " << p.y() << ", " << p.z()
     << ", m=" << p.m() << ")";
  return os;
}

ostream& operator<< ( ostream& os, const rave::Vector7D & p )
{
  os << "(" << setprecision(6) << fixed << p.x() << ", " << p.y() << ", " 
     << p.z() << " , " << p.px() << ", " << p.py() << ", " << p.pz();
  os << ", " << dynamic_cast < const rave::Vector7D & > (p).m();
  os << " )";
  return os;
}

ostream& operator<< ( ostream& os, const rave::KinematicParticle & t )
{
  os << t.fullstate();
  return os;
}
#endif

ostream& operator<< ( ostream& os, const rave::Covariance3D & p )
{
  #define sep3 " "<<setw(12)
  os << setprecision(4) << scientific << right
     << "(" << sep3 << p.dxx()  << sep3 << p.dxy()  << sep3 << p.dxz() << endl
     << "(" << sep3 << p.dxy()  << sep3 << p.dyy()  << sep3 << p.dyz() << endl
     << "(" << sep3 << p.dxz()  << sep3 << p.dyz()  << sep3 
     << p.dzz() << ")" << endl;
  return os;
}

ostream& operator<< ( ostream& os, const rave::Covariance33D & p )
{
  #define sep3 " "<<setw(12)
  os << setprecision(4) << scientific << right
     << "(" << sep3 << p.dxpx() << sep3 << p.dxpy() << sep3 << p.dxpz() << endl
     << sep3 << p.dypx() << sep3 << p.dypy() << sep3 << p.dypz() << endl
     << sep3 << p.dxpz() << sep3 << p.dypz() << sep3 << p.dzpz() << sep3 
     << ")" << endl;
  return os;
}

ostream& operator<< ( ostream& os, const rave::Covariance6D & p )
{
  string s="   ";
  os << "(" << setprecision(6) << scientific 
     << p.dxx() << s << p.dxy() << s << p.dxz()
     << s << p.dxpx() << s << p.dxpy() << s << p.dxpz() << endl
     << p.dxy() << s << p.dyy() << s << p.dyz() << s << p.dypx()
     << s << p.dypy() << s << p.dypz() << endl

     << p.dxz() << s << p.dyz() << s << p.dzz() << s << p.dzpx()
     << s << p.dzpy() << s << p.dzpz() << endl

     << p.dxpx() << s << p.dypx() << s << p.dzpx() << s << p.dpxpx()
     << s << p.dpxpy() << s << p.dpxpz() << endl

     << p.dxpy() << s << p.dypy() << s << p.dzpy() << s << p.dpxpy()
     << s << p.dpypy() << s << p.dpypz() << endl

     << p.dxpz() << s << p.dypz() << s << p.dzpz() << s << p.dpxpz()
     << s << p.dpypz() << s << p.dpzpz() 
     << ")" << endl;
    
  return os;
}

/*
ostream& operator<< ( ostream& os, const rave::Covariance3To6D & p )
{
  string s="   ";
  os << "(" << setprecision(4) << scientific << p.dxx() << s << p.dxy() 
     << s << p.dxz()
     << s << p.dxpx() << s << p.dxpy() << s << p.dxpz() << endl
     << p.dxy() << s << p.dyy() << s << p.dyz() << s 
     << p.dypx() << s << p.dypy() << s << p.dypz() << endl
     << p.dxz() << s << p.dyz() << s << p.dzz() << s 
     << p.dzpx() << s << p.dzpy() << s << p.dzpz() // << endl
  //   << p.dxpx() << s << p.dypx() << s << p.dzpx() << s << endl
  //   << p.dxpy() << s << p.dypy() << s << p.dzpy() << s << endl
  //   << p.dxpz() << s << p.dypz() << s << p.dzpz() << s 
     << ")" << endl;
  return os;
}
*/

ostream& operator<< ( ostream& os, const rave::Ellipsoid3D & p )
{
  rave::Point3D pt = p.point();
  const rave::Covariance3D & cov = p.covariance();
  os << setprecision(4) << fixed << pt << endl << "Cov=" << endl << scientific << cov;
  return os;
}

ostream& operator<< ( ostream& os, const rave::Vector6D & p )
{
  os << "(" << setprecision(6) << fixed << p.x() << ", " << p.y() << ", " << p.z() << " , "
  << p.px() << ", " << p.py() << ", " << p.pz();
  if ( dynamic_cast < const rave::Vector7D * > ( &p ) != 0 ) 
  {
    // os << setw(6) << setprecision(1) << p.m()  << ")";
    os << ", " << dynamic_cast < const rave::Vector7D & > (p).m();
  };
  os << " )";
  return os;
}

ostream& operator<< ( ostream& os, const rave::Track & t )
{
  os << t.state();
  return os;
}


ostream& operator<< ( ostream& os, const rave::Vertex & v )
{
  os << "id: " << v.id() << ", position: " << v.position();
  return os;
}
