#ifndef _RaveVersion_H_
#define _RaveVersion_H_

#include <string>

namespace rave
{
  RaveDllExport std::string Version(); 
}

#endif
