#ifndef _RAVEVECTOR3D_H_
#define _RAVEVECTOR3D_H_

#include <rave/Point3D.h>

namespace rave
{

typedef Point3D Vector3D;

}

#endif
