#ifndef _RaveCharge_H_
#define _RaveCharge_H_

namespace rave
{
  typedef signed Charge;
}

#endif
