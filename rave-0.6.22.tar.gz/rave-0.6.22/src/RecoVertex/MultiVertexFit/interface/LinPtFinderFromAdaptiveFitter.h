#ifndef LinPtFinderFromAdaptiveFitter_H
#define LinPtFinderFromAdaptiveFitter_H

#include "Vertex/LinearizationPointFinders/interface/LinPtFinderFromVertexFitter.h"
// LinPtFinderFromVertexFitter

class LinPtFinderFromAdaptiveFitter : public LinPtFinderFromVertexFitter
{
public:
  LinPtFinderFromAdaptiveFitter ();
};

#endif
