#if 0
#include "RecoVertex/MultiVertexFit/interface/LinPtFinderFromAdaptiveFitter.h"
#include "RecoVertex/RobustVertexFit/interface/AdaptiveVertexFitter.h"

LinPtFinderFromAdaptiveFitter::LinPtFinderFromAdaptiveFitter () :
    LinPtFinderFromVertexFitter ( AdaptiveVertexFitter() ) {}

#endif
