#include "RecoVertex/SkeletonVertexReco/interface/SkeletonVertexReconstructor.h"

using namespace std;

vector<TransientVertex> SkeletonVertexReconstructor::vertices (
    const vector<reco::TransientTrack> & tracks ) const
{
  return vector < TransientVertex > ();
}

