#ifndef ParticleMass_H
#define ParticleMass_H

  
typedef  double ParticleMass;  
  
#endif
