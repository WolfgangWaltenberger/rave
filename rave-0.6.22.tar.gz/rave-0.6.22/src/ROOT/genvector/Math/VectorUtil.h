// @(#)root/mathcore:$Id: VectorUtil.h 22516 2008-03-07 15:14:26Z moneta $
// Authors: W. Brown, M. Fischler, L. Moneta    2005  

#ifndef ROOT_Math_VectorUtil 
#define ROOT_Math_VectorUtil 


#include "Math/GenVector/VectorUtil.h"


#endif
