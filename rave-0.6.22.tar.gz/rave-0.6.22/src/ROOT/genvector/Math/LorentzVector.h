// @(#)root/mathcore:$Id: LorentzVector.h 22516 2008-03-07 15:14:26Z moneta $
// Authors: W. Brown, M. Fischler, L. Moneta    2005  

#ifndef ROOT_Math_LorentzVector 
#define ROOT_Math_LorentzVector 


#include "Math/GenVector/LorentzVector.h"


#endif
