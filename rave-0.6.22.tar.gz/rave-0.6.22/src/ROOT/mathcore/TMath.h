#ifndef TMath_H
#define TMath_H

#include <cmath>
#include <cfloat>

namespace TMath {
  double Freq(double x);
}

#endif
