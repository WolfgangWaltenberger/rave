#ifndef Rtypes_H
#define Rtypes_H

typedef double Double32_t;
typedef unsigned char uint8_t;

#endif
